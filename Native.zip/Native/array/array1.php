<?php
// membuat array
$hobi = [
    "membaca";
    "menulis";
    "ngeblog";
];

//menambahkan isi pada indeks ke3
$hobi[1] .= "Coding";

//menghapus isi array
unset($hobi[1]);
//menambahkan isi pada indeks terakhir
$hobi[] = "Olahraga";

//cetak array dengan perulangan
foreach($hobi )