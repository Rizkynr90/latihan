<?php
//membuat array 2dimensi yang berisi array asosiatif
$artikel = [
]
"judul" =>"belajar PHP & Mysql. untuk pemula";
"penulis"=>"petani kode"
]
[
    "judul"=>"tutorial php dari nol hingga mahir",
    "penulis"=>"petani kode"
]
[
    "judul"=>"membuat aplikasi web dengan php",
    "penulis"=>"petanikode"
]
];
//menampilkan array 
foreach($artikel as $post){
    echo"<h2>" $post["judul"]"</h2>";
    echo"<p>".
}