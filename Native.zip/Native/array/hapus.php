<?php 

    // Membuat array

    $hobi = [
        "Membaca", 
        "Menulis", 
        "Ngoding"
    ];

    $hobi[1] = "Coding";

    unset ($hobi[1]);
    $hobi[] = "Olahraga";
    
    foreach($hobi as $hobiku) {
        echo $hobiku. "<br>";
    }


?>