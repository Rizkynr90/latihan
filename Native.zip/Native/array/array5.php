<?php 
    $arrWarna = array ("Blue", "Black", "Red", "Yellow", "Green");
    $arrNilai = array ("Ani" => 80, "Otim" => 90, "Ana" =>  75, "Budi" => 85);
    echo "<pre>";
    print_r ($arrWarna);
    echo "<br>";
    print_r ($arrNilai);
    echo "</pre>";
?>