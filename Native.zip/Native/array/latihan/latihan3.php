<?php
    $list = [
        ["dosen" => "Udin", "listing" => [
            [ "nama" => "Aida", "MataKuliah" => [
            ["MataKuliah" => "Matematika "],
            ["MataKuliah" => "Bahasa Indonesia"],
            ["MataKuliah" => "Bahasa Inggris"]
        ],
            "Hobi" => [
            ["Hobi" => "Membaca"],
            ["Hobi" => "Main Api"],
            ["Hobi" => "Berlari"]
            ]
        ],
            [ "nama" =>"Dante",
            "MataKuliah" => [
            ["MataKuliah" => "IPA"],
            ["MataKuliah" => "Penjaskes"],
            ["MataKuliah" => "Sejarah"]
        ],
            "Hobi" => [
            ["Hobi" => "Bola"],
            ["Hobi" => "Berenang"],
            ["Hobi" => "Mengobrol"]
            ]
        ],
            [ "nama" => "Farrel",
            "MataKuliah" => [
            ["MataKuliah" => "PAI"],
            ["MataKuliah" => "BK"],
            ["MataKuliah" => "PKN"]
        ],
            "Hobi" => [
            ["Hobi" => "Menambang"],
            ["Hobi" => "Menyanyi"],
            ["Hobi" => "Ngoding"]
            ]
           ]
          ]
         ],
        ["dosen" => "Jajang", "listing" => [
            [ "nama" => "Aida", "MataKuliah" => [
            ["MataKuliah" => "Matematika "],
            ["MataKuliah" => "Bahasa Indonesia"],
            ["MataKuliah" => "Bahasa Inggris"]
        ],
            "Hobi" => [
            ["Hobi" => "Berenang"],
            ["Hobi" => "Lompat Tali"],
            ["Hobi" => "Main Api"]
            ]
        ],
            [ "nama" =>"Dante",
            "MataKuliah" => [
            ["MataKuliah" => "IPA"],
            ["MataKuliah" => "Penjaskes"],
            ["MataKuliah" => "Sejarah"]
        ],  
            "Hobi" => [
            ["Hobi" => "Bola"],
            ["Hobi" => "Bermain"],
            ["Hobi" => "Mengobrol"]
            ]
        ],
            [ "nama" => "Farrel",
            "MataKuliah" => [
            ["MataKuliah" => "Agama"],
            ["MataKuliah" => "BK"],
            ["MataKuliah" => "PKN"]
        ],

            "Hobi" => [
            ["Hobi" => "Main Kembang Api"],
            ["Hobi" => "Merawat Binatang"],
            ["Hobi" => "Main Tanah"]
            ]
          ]
        ]
      ]
    ];
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>
    </head>
    <body>
        
        <table border="1" width = "50%">
        <tr bgcolor ="yellow">
            <th>No</th>
            <th>Nama Mahasiswa</th>
            <th>Nama Dosen</th>
            <th>Mata Kuliah</th>
            <th>Hobi</th>
        </tr>  
        <?php $no=1; ?>
            <?php foreach($list as $key => $index) {
            foreach ($index['listing'] as $menu) { ?>
                <tr bgcolor = "aquamarine">
                <td>
                <?php echo "<center>".$no++; ?></td>
                  <td><?php echo "<center>".$menu['nama'];?></td>
                  <td><?php echo "<center>".$index['dosen']?></td>
              
            <?php echo "<td>";
                  foreach ($menu['MataKuliah'] as $matkul) { ?>   
                  <?php echo "<li style = list-style:none;>".$matkul['MataKuliah']."</li>";?>
            <?php } ?>
            <?php
                 echo "<td>";
                foreach ($menu['Hobi'] as $hobi) {
                    echo "<li style = list-style:none;>". $hobi['Hobi']. "</li>";
                }
                echo "</td>";
               }
            }
            ?>
          </td>
        </tr>       
      </table>
    </body>
  </html>