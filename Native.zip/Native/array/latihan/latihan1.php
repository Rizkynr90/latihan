<html lang="en">
<head>
    <title>Document</title>
</head>
<body>
        <form action="" method="post">
            <table>
                <tr>
                    <td>Masukan Jumlah Data</td>
                    <td>:</td>
                    <td><input type="number" min="0" name="angka"></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" name="input" value="Save"></td>
                       
                </tr>
            </table>
        </form>
    <?php
        if (isset($_POST['input'])) {
            $row = $_POST['angka'];
    ?>
    <fieldset>
        <table>
            <form action="latihan1.2.php" method="post">
            <?php
                for ($i = 1; $i <= $row; $i++){
            ?>
            <tr>
                <th colspan=2>Data Ke : <?php echo $i; ?></th>
                <td>Nama</td>
                <td>:</td>
                <td><input type="text" name="nama[]"></td>
            </tr>
            <tr>
                <th colspan=2></th>
                <td>Asal Sekolah</td>
                <td>:</td>
                <td><input type="text" name="sekolah[]"></td>
            </tr>
            <tr>
                <th colspan=2></th>
                <td>Nilai Bahasa Indonesia</td>
                <td>:</td>
                <td><input type="number" min="0" max ="100" name="indo[]" required></td>
            </tr>
            <tr>
                <th colspan=2></th>
                <td>Nilai Matematika</td>
                <td>:</td>
                <td><input type="number" min="0" max ="100" name="mtk[]" required></td>
            </tr>
            <tr>
                <th colspan=2></th>
                <td>Nilai Bahasa Inggris</td>
                <td>:</td>
                <td><input type="number" min="0" max ="100" name="inggris[]" required></td>
            </tr>
            <tr>
                <th colspan=2></th>
                <td>Nilai IPA</td>
                <td>:</td>
                <td><input type="number"  min="0" max ="100" name="ipa[]" required></td>
            </tr>
            <?php } ?>
            <tr>
                <th colspan=2></th>
                <td></td>
                <td></td>
                <td><input type="submit" name="save" value="Save"></td>
            </tr>
          </form>
         </table>
        </fielset>
    <?php } ?>
</body>
</html>