<?php 
    $list = [
        ["dosen" => "Udin", "listing" => [
            [ "nama" => "Aida", "MataKuliah" => [
            ["MataKuliah" => "Matematika "],
            ["MataKuliah" => "Bahasa Indonesia"],
            ["MataKuliah" => "Bahasa Inggris"]
        ],

            "Hobi" => [
            ["Hobi" => "Membaca"],
            ["Hobi" => "Main Api"],
            ["Hobi" => "Berlari"]
            ]
        ],

            [ "nama" =>"Dante",
            "MataKuliah" => [
            ["MataKuliah" => "IPA"],
            ["MataKuliah" => "Penjaskes"],
            ["MataKuliah" => "Sejarah"]
        ],
            
            "Hobi" => [
            ["Hobi" => "Bola"],
            ["Hobi" => "Berenang"],
            ["Hobi" => "Mengobrol"]
            ]
        ],

            [ "nama" => "Farrel",
            "MataKuliah" => [
            ["MataKuliah" => "PAI"],
            ["MataKuliah" => "BK"],
            ["MataKuliah" => "PKN"]
        ],

            "Hobi" => [
            ["Hobi" => "Menambang"],
            ["Hobi" => "Menyanyi"],
            ["Hobi" => "Ngoding"]
            ]
        ],
        ]
        ],
        
        ["dosen" => "Jajang", "listing" => [
            [ "nama" => "Aida", "MataKuliah" => [
            ["MataKuliah" => "Matematika "],
            ["MataKuliah" => "Bahasa Indonesia"],
            ["MataKuliah" => "Bahasa Inggris"]
        ],

            "Hobi" => [
            ["Hobi" => "Berenang"],
            ["Hobi" => "Lompat Tali"],
            ["Hobi" => "Main Api"]]],

            [ "nama" =>"Dante",
            "MataKuliah" => [
            ["MataKuliah" => "IPA"],
            ["MataKuliah" => "Penjaskes"],
            ["MataKuliah" => "Sejarah"]
        ],
            
            "Hobi" => [
            ["Hobi" => "Bola"],
            ["Hobi" => "Bermain"],
            ["Hobi" => "Mengobrol"]
            ]
        ],

            [ "nama" => "Farrel",
            "MataKuliah" => [
            ["MataKuliah" => "Agama"],
            ["MataKuliah" => "BK"],
            ["MataKuliah" => "PKN"]
        ],

            "Hobi" => [
            ["Hobi" => "Main Kembang Api"],
            ["Hobi" => "Merawat Binatang"],
            ["Hobi" => "Main Tanah"]
            ]
        ]
        ]
        ]
    ];
    $no = 1;
    foreach ($list as $key => $index) {
        echo "Nama Wali Doses : ". $index['dosen']. "<br>";
        echo "Daftar Mahasiswa : ";
        echo "<ul>";

        foreach ($index['listing'] as $nama) {
            echo "<li>Data Ke ".$no++."</li>";
            echo "Daftar Mahasiswa : ".$nama['nama']. "<br>";
            echo "Daftar Mata Kuliah :";
            echo "<ol>";
        
            foreach ($nama['MataKuliah'] as $matkul) {
                echo "<li>".$matkul['MataKuliah']."</li>";
            }
            echo "</ol>";
        }
        echo "Daftar Hobi : ";
        echo "<ol>";

        foreach ($nama['Hobi'] as $hobi) {
            echo "<li>".$hobi['Hobi']."</li>";
        }
        echo "</ol>";
        echo "</ul>";
        
    }
       
?>