<?php
    if (isset($_POST['save'])){
        $nama = $_POST['nama'];
        $sekolah = $_POST['sekolah'];
        $indo = $_POST['indo'];
        $mtk = $_POST['mtk'];
        $inggris = $_POST['inggris'];
        $ipa = $_POST["ipa"];
    }
?>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>
    <fieldset>
        <center><h2>Data Siswa</h2>
        <table border = "1">
            <center>
            <tr bgcolor="yellow">
                <th>Nama</th>
                <th>Asal Sekolah</th>
                <th>Nilai Bahasa Indonesia</th>
                <th>Nilai Matematika</th>
                <th>Nilai Bahasa Inggris</th>
                <th>Nilai IPA</th>
                <th>Total Nilai</th>
                <th>Rata - Rata</th>
                <th>Keterangan</th>
            </tr>
            
            <?php
            $no = 1;
            for ($i = 0; $i < count($nama); $i++) { ?>
            <tr bgcolor="azure">
                <td><?php echo "<center>".$no++; ?></td>
                <td><?php echo "<center>".$nama[$i]; ?></td>
                <td><?php echo "<center>".$indo[$i]; ?></td>
                <td><?php echo "<center>".$mtk[$i]; ?></td>
                <td><?php echo "<center>".$inggris[$i]; ?></td>
                <td><?php echo "<center>".$ipa[$i]; ?></td>
                <?php $total = $indo[$i] + $mtk[$i] + $inggris[$i] + $ipa[$i];?>
                <td><?php echo "<center>".$total; ?></td>
                <?php if ($total >= 340) {
                        $ket = "Anda Lulus";
                    } else {
                        $ket = "Anda Tidak Lulus";
                    } 
                    ?>
                <?php $rata = ($indo[$i] + $mtk[$i] + $inggris[$i] + $ipa[$i]) / 4;?>
                <td><?php echo "<center>".$rata;?></td>
                <td><?php echo "<center>".$ket; ?></td>
            </tr>
            <?php } ?>
        </table>
    </fieldset>
    <form action = "latihan1.php" method="post">
    <input type="submit" name="Back" value="Back">
</body>
</html>