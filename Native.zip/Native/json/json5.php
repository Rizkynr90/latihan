<?php
$dataMhs = [
    ["nama" => "Mahmud","domisili" => "Bandung"],
    ["nama" => "Udin","domisili" => "Tasik"],
    ["nama" => "Encep","domisili" => "Majalaya"],
    ["nama" => "Entis","domisili" => "Ciamis"]
];

$data = json_encode($dataMhs);
echo $data;
?>