<?php
    function hello() 
    {   
     return "Hello World";
    }
    echo hello();
?>