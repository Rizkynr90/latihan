<?php 
    function hitungUmur($thn_lahir,$thn_sekarang)
    {
        $umur = $thn_sekarang - $thn_lahir;
        return $umur;
    }
    function perkenalan($nama,$salam = "Assalamualaikum")
    {
        echo $salam . "<br>";
        echo "Perkenalkan, Nama Saya ".$nama."<br>";
        echo "Saya Berusia ".hitungUmur(2004, 2021)." Tahun"."<br>";
        echo "Senang berkenalan dengan anda";
    }
    perkenalan("Rizky");
?>