<?php 
    $nilai = array (90, 80 ,60, 100, 127, 81, 51, 99);

    function nilaimaksimal($nilai) {
        $n = count($nilai);
        $maksimal = $nilai[0];
        for ($i = 1; $i < $n; $i++) {
            if ($maksimal < $nilai[$i]) {
                $maksimal = $nilai[$i];
            }
        }
        return $maksimal;
    }
    function nilaiminimal($nilai) {
        $n = count($nilai);
        $minimal = $nilai[0];
        for ($i = 1; $i < $n; $i++) {
            if ($minimal > $nilai[$i]) {
                $minimal = $nilai[$i];
            }
        }
        return $minimal;
    }
    echo "Nilai Maksimal : ".nilaimaksimal($nilai)."<br>";
    echo "Nilai Minimal : ".nilaiminimal($nilai);
?>