<?php 
    function tentangSaya($nama, $umur)
    {
       
        return "Hi, Saya $nama dan umur saya $umur Tahun.";
    }
    echo tentangSaya("Rizky Nurahman",17);
?>