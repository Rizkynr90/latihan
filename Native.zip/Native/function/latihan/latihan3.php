<html>
    <head></head>
    <body>
       
    <form action = "" method="POST">
    
    <table>
        <tr>
    <td>Nama</td> 
    <td>:</td> 
    <td><input type="text" name= "nama" required></td>
</tr>   
<tr>
    <td>Jenis Kelamin</td> 
    <td>:</td> 
    <td><input type="radio" name= "jk" value="Laki-Laki" >Laki laki
    <input type="radio" name= "jk" value="Perempuan" >Perempuan
</td>
</tr>
<tr>
    <td>Alamat</td> 
    <td>:</td> 
    <td><textarea name="alamat"></textarea></td>
</tr>   
<tr>
    <td>Hobi</td> 
    <td>:</td> 
    <td><input type="checkbox" name="hobi[]"  value="Main Api">Main Api<br>
        <input type="checkbox" name="hobi[]"  value="Berenang">Berenang<br>
        <input type="checkbox" name="hobi[]"  value="Travelling">Travelling<br>
        <input type="checkbox" name="hobi[]"  value="Marathon">Marathon<br>
        <input type="checkbox" name="hobi[]"  value="Lompat Tali">Lompat Tali<br>
        <input type="checkbox" name="hobi[]"  value="Membaca komik">Membaca Komik
    </td>
</tr>   
<tr>
    <td></td>
    <td></td>
    <td><input type = "submit" name ="save" value="Save"></td>
</td>
</table>
    </form>
    </body>
</html>
<?php 
    if (isset($_POST['save'])) {
        $nama = $_POST['nama'];
        $jk = $_POST['jk'];
        $alamat = $_POST['alamat'];
        $hobi = $_POST['hobi'];

    function tampilBiodata($nama,$jk,$alamat,$hobi) {
        $biodata = "Nama : ".$nama."<br>";
        $biodata .= "Jenis Kelamin : ".$jk."<br>";
        $biodata .= "Alamat : ".$alamat."<br>";
        $biodata .= "Hobi : ".implode(", ",$hobi)."<br>";
        return $biodata;
        }   
        echo tampilBiodata($nama,$jk,$alamat,$hobi);
    }
?>