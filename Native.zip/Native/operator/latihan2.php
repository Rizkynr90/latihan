<?php 
    $angka = 0;
    for ($i = 1; $i <= 10; $i++) {
        $angka += 2; 
        for ($j = 1; $j <= $i; $j++) {
            $k = $j + $angka;
            echo " $k";
        }
            echo "<br>";
    }
    echo "<hr>";
    for ($a = 1; $a <= 5; $a++) {
        for ($b = 1; $b <= 5; $b++) {
            $c = $b + $a;
            echo " $c";
        }
            echo "<br>";
    }
    
?>