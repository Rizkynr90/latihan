<?php
    $member = "ya";
    $totalbelanja = 100000;


    if($member == "ya") {
        if($totalbelanja >= 250000) {
            $diskon = 0.1 * $totalbelanja;
        } else if($totalbelanja >= 100000) {
             $diskon = 0.05 * $totalbelanja;
            }
        } else {
             if ($totalbelanja >= 100000) {
                 $diskon = 0.025 * $totalbelanja;
             }
        }
    echo "Kartu member : $member<br>";
    echo "Total Belanja : $totalbelanja<br>";
    echo "Diskon : $diskon<br>";
    echo "Yang harus dibayar : $totalbelanja";
?>