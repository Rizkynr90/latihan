<?php
    if (isset($_POST['input'])) {
        $nama = @$_POST['nama'];
        $alamat = @$_POST['alamat'];
        $tanggal = @$_POST['tgl'];
        $agama = @$_POST['agama'];
        $jk = @$_POST['jenis'];
        $ket = @$_POST['name']; 
        echo "Nama : <b>$nama</b><br>";
        echo "Alamat : <b>$alamat</b><br>";
        echo "Tanggal Lahir : <b>$tanggal</b><br>";
        echo "Agama : <b>$agama</b><br>";
        echo "Jenis Kelamin : <b>$jk</br><br>";
        echo "Keterangan : <b>$ket</b><br>";
    }
?>

    <a href = "form.php">Back</a>