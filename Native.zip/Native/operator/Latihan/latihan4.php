<html>
    <head></head>
    <body>
    <form action = "" method ="POST">
        <table>
    <tr>
        <td>Nama</td> 
        <td>:</td>
        <td><input type="text" name="nama" required><br></td>
    </tr>   
    <tr>
        <td>Jenis Kelamin</td>
        <td>:</td>
        <td><input type="radio" name="jk" value = "Laki - Laki" >Laki-Laki
            <input type ="radio" name="jk" value = "Perempuan" >Perempuan
        <br></td>
    </tr>
    <tr>
        <td>Agama</td>
        <td>:</td>
        <td><select name ="agama" value="agama" required>
            <option value="">Pilih :</option>
            <option value= "Islam">Islam</option>
            <option value= "Kristen">Kristen</option>
            <option value= "Hindu">Hindu</option>
            <option value= "Buddha">Buddha</option>
        </select>
        </td>
    </tr>
    <tr>
        <td>Golongan</td>
        <td>:</td>
        <td>
        <select name = "pilihan" value = "golongan" required>
        <option value ="">Pilih: </option>
        <option value="1">Golongan 1</option>
        <option value="2">Golongan 2</option>
        <option value="3">Golongan 3</option>
        <option value="4">Golongan 4</option>
        </select>
        </td>
    </tr>
    <tr>
            <td>Jumlah Jam</td>
            <td>:</td>
            <td><input type = "number" name="jam"><td>
    </tr>
    <tr>
    <td></td>
    <td></td>
        <td><input type = "submit" name = "hitung" value = "Menghitung"></td>
    </tr>
    </form>
</table>
    </body>
</html>
<?php 
        if (isset($_POST['hitung'])){
            $nama = $_POST['nama'];
            $jk = $_POST['jk'];
            $agama = $_POST['agama'];
            $golongan = $_POST['pilihan'];
            $jam = $_POST['jam'];
            echo "Nama : $nama<br>";
            echo "Jenis Kelamin : $jk<br>";
            echo "Agama : $agama<br>";
            echo "Golongan : $golongan<br>";
            echo "Jumlah Jam : $jam Jam<br>";
            echo "<hr>";
            if ($golongan == 1) {
                $gaji = 1500000;
                $tunjangan = 150000;
            } else if ($golongan == 2) {
                $gaji = 2000000;
                $tunjangan = 200000;
            } else if ($golongan == 3) {
                $gaji = 2500000;
                $tunjangan = 250000;
            } else if ($golongan == 4) {
                $gaji = 3000000;
                $tunjangan = 300000;
            } 
            if ($jam > 173) {
                $sisajam = $jam - 173;
                $lembur = 20000 * $sisajam;
            } else {
                $lembur = 0;
            }
            echo "Gaji Pokok : Rp$gaji<br>";
            echo "Gaji Lembur : Rp$lembur<br>";
            $pajakpokok = ($gaji * 5) / 100;
            echo "Pajak Gaji Pokok : Rp$pajakpokok<br>";
            $pajaklembur = ($lembur * 5) / 100;
            echo "Pajak Gaji Lembur : Rp$pajaklembur<br>";
            $totalpajak = $pajakpokok + $pajaklembur;
            echo "Total Pajak : Rp$totalpajak<br>";
            echo "Tunjangan Pengabdian : Rp$tunjangan<br>";
            $totalgaji = ($gaji + $tunjangan) + $lembur;
            $total = $totalgaji - $totalpajak;
            echo "Gaji Diterima : Rp$total";   
        }
?>