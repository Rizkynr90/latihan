<html>
<head>
</head>
<body>
    <form action = "" method ="POST">
    Masukan jumlah bintang : <input type="number" name= "bintang"><br>
    <input type= "submit" name = "hitung" value = "Tampil">
</form>
</body>
</html>
<?php 
        if (isset($_POST['hitung'])) {
            $bintang = $_POST['bintang'];
            echo "<center>";
                for ($i = 0; $i <= $bintang; $i++) {
                    for ($j = $bintang; $j >= $i; $j--) {
                        echo " ";
                    } 
                    for ($k = 0; $k <= $i; $k++) {
                        echo " * ";
                    }
                    echo "<br>";
                }
                for ($a = 0; $a <= $bintang; $a++) {
                    for ($b = 0; $b <= $a; $b++) {
                        echo " ";
                    } 
                    for ($c = $bintang; $c >= $a; $c--) {
                        echo " * ";
                    }
                    echo "<br>";
                }
                echo "</center>";
           
        }
?>