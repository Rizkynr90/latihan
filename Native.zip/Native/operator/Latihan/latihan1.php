<html>
    <head></head>
    <body>
    <form action = "" method="POST">
    <table>
        <tr>
    <td>Masukan Bilangan ke 1</td> 
    <td>:</td> 
    <td><input type="number" name= "bilang1" required></td>
</tr>   
<tr>
    <td>Masukan Bilangan ke 2</td> 
    <td>:</td> 
    <td><input type="number" name= "bilang2" required></td>
</tr>
<tr>
    <td></td>
    <td></td>
    <td><input type = "submit" name ="hsl" value="Hasil"></td>
</td>
</table>
    </form>
    </body>
</html>
<?php
if (isset($_POST['hsl'])) {
        $blg1 = @$_POST['bilang1'];
        $blg2 = @$_POST['bilang2'];
        $hasil1 = $blg1 + $blg2;
        echo "$blg1 + $blg2 : $hasil1<br>";
        $hasil2 = $blg1 - $blg2;
        echo "$blg1 - $blg2 : $hasil2<br>";
        $hasil3 = $blg1 * $blg2;
        echo "$blg1 * $blg2 : $hasil3<br>";
        $hasil4 = $blg1 / $blg2;
        echo "$blg1 / $blg2 : $hasil4";
    }
?>