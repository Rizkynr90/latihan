<html>
    <head></head>

    <body>

    <form action = "" method="POST">
        <h1>Halaman Lingkaran</h1>
    <table>
        <tr>
    <td>Masukan Jari - Jari : </td> 
    <td>:</td> 
    <td><input type="number" name= "jari" required></td>
</tr>   
</table>
<input type = "submit" name ="hasil" value="Hasil">

    </form>
    </body>
</html>

<?php 
    if(isset($_POST['hasil'])) {
        $jari = @$_POST['jari'];

        $luas = 3.14 * $jari * $jari;
        echo "Luas Lingkaran : $luas<br>";
        $keliling = 2 * 3.14 * $jari * $jari;
        echo "Keliling Lingkaran : $keliling<br>";

    }

?>

<a href = "latihan2.php">Back</a>