    <?php 
        if (isset($_POST['input'])) {
            $nama = $_POST['nama'];
            $nik = $_POST['nik'];
            $jk = $_POST['jk'];
            $agama = $_POST['agama'];
            $tglpinjam = $_POST['tglpinjam'];
            $tglkembali = $_POST['tglkembali'];
            $penjamin = $_POST['penjamin'];
            $mobil = $_POST['mobil'];
            $plat = $_POST['plat'];
            $jenis = $_POST['jenis'];
            $merk = $_POST['merk'];
            $supir = $_POST['supir'];
        }
    ?>    
    <html>
        <head></head>
        <body>
        <form  action ="latihan5.3.php" method="POST">
            <input type= "hidden" name = "nama" value=<?php echo "$nama";?>>
            <input type= "hidden" name = "nik" value=<?php echo "$nik";?>>
            <input type= "hidden" name = "jk" value=<?php echo "$jk";?>>
            <input type= "hidden" name = "agama" value=<?php echo "$agama";?>>
            <input type= "hidden" name = "tglpinjam" value=<?php echo "$tglpinjam";?>>
            <input type= "hidden" name = "tglkembali" value=<?php echo "$tglkembali";?>>
            <input type= "hidden" name = "penjamin" value=<?php echo "$penjamin"?>>
            <input type= "hidden" name = "mobil" value=<?php echo "$mobil"?>>
            <input type= "hidden" name = "plat" value=<?php echo "$plat"?>>
            <input type= "hidden" name = "jenis" value=<?php echo "$jenis"?>>
            <input type= "hidden" name = "merk" value=<?php echo "$merk"?>>
            <input type= "hidden" name = "supir" value=<?php echo "$supir"?>>
            <table>
                <tr>      
                <td>Tanggal Kembali</td> 
                <td>:</td> 
                <td><input type = "date" name="tglverifikasi" value ="tglverifikasi" required></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
            <td><input type="submit" name="input" value = "Simpan"></td> 
       </form>
    </body>
</html>

