<?php
    $uangucup = 100000;
    echo "Uang Ucup adalah : $uangucup<br>";
    echo "<hr>";
    
    $hargaminum = 15000;
    $sisa = $uangucup - $hargaminum;
    echo "Jajan minum : $hargaminum<br>";
    echo "Sisa uang ucup jajan minum : $sisa<br>";
    echo "<hr>";

    $hargasosis = 25000;
    $sisa2 = $sisa - $hargasosis;
    echo "Jajan minum : $hargasosis<br>";
    echo "Sisa uang ucup jajan sosis bakar : $sisa2";
    echo "<hr>";

    $sedekah = ($sisa2 * 10) / 100;
    $sisa3 = $sisa2 - $sedekah;
    echo "Sedekah ke musafir sebesar 10% dari ".$sisa2." yaitu sebesar ".$sedekah."<br>";
    echo "Sisa uang ucup : $sisa3<br>";
    echo "<hr>";

    $nemu = ($sisa3 * 50) / 100;
    echo "Nemu uang dijalan sebesar 50% dari uang ucup ".$sisa3." yaitu sebesar ".$nemu."<br>";
    echo "Sisa uang ucup sekarang = ".$sisa3." + ".$nemu."<br>"; 
    echo "<hr>";

    $total = $sisa3 + $nemu;
    echo "Uang ucup = $total";
    ?>