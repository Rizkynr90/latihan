<?php 
    $username = "rizky";  
    $email = "rizky@gmailcom";
    $pass = 123;
    
    echo "Username / email : $username<br>";
    echo "password : $pass<br>";
    echo "cek login : ". (($username == "rizky" || $email == "rizky@gmailcom" && $pass == 123));
?>