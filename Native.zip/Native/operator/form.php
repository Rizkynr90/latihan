<html>
    <head></head>
    <body>
    <form action = "proses.php" method ="POST" name ="input">
        <table>
    <tr>
        <td>Nama</td> 
        <td>:</td>
        <td><input type="text" name="nama" required><br></td>
    </tr>   
    <tr>
        <td>Alamat</td>
        <td>:</td>
        <td><input type="text" name="alamat" required><br></td>
    </tr>
    <tr>
        <td>Tanggal</td>
        <td>:</td>
        <td><input type="date" name="tgl" required><br></td>
    </tr>
    <tr>
        <td>Agama</td>
        <td>:</td>
        <td><select name ="agama" value="agama" required>
            <option value="">Pilih :</option>
            <option value= "Islam">Islam</option>
            <option value= "Kristen">Kristen</option>
            <option value= "Hindu">Hindu</option>
            <option value= "Buddha">Buddha</option>
        </select>
        </td>
    </tr>
    <tr>
        <td>Jenis Kelamin</td>
        <td>:</td>
        <td>
            <input type ="radio" name="jenis" value="Laki -Laki">Laki - Laki
            <input type ="radio" name="jenis" value="Perempuan">Perempuan
    </tr>
    <tr>
        <td>Keterangan</td>
        <td>:</td>
        <td><textarea name="name"></textarea>
    </table>
        <input type = "submit" name ="input" value="Save">
        <input type = "reset" name = "reset" value = "Clear">
    </form>


    </body>

</html>

<?php
    if (isset($_POST['input'])) {
        $nama = @$_POST['nama'];
        $alamat = @$_POST['alamat'];
        $tanggal = @$_POST['tgl'];
        $agama = @$_POST['agama'];
        $jk = @$_POST['jenis'];
        $ket = @$_POST['name']; 
        echo "Nama : <b>$nama</b><br>";
        echo "Alamat : <b>$alamat</b><br>";
        echo "Tanggal Lahir : <b>$tanggal</b><br>";
        echo "Agama : <b>$agama</b><br>";
        echo "Jenis Kelamin : <b>$jk</br><br>";
        echo "Keterangan : <b>$ket</b><br>";
    }
?>

    <a href = "form.php">Back</a>