<?php
class kucing
{
    public $warna = "coklat";
    public $jumlahkaki = 4;
    public $jenisBulu = "panjang";
    public $makanandfavorite = "Ikan pindang";

    public function bersuara()
    {
        return "meong...meong...meong";
    }
    public function berburu()
    {
        return "berburu ikan";
    }
}

$kucing1 = new kucing();
echo "warna kucing: " . $kucing->warna . "<br>";
echo "sifat kucing: " . $kucing->bersuara() . "<hr>";

$kucing2 = new kucing();
//set warna kucing
$kucing2->warna = "oren";
echo "warna kucing : " . $kucing2->warna . "<br>";
echo "sifat kucing : " . $kucing2->berburu() . "<hr>";
