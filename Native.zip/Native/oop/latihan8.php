<html>
    <head></head>
    <body>
        <h2>Program Penggajian Web Developer</h2>
    <form action="" method="POST">
      <table>
        <tr>
          <td>Nama</td>
          <td>:</td>
          <td><input type="text" name="nama"></td>
        </tr>
        <tr>
          <td>Jenis Kelamin</td>
          <td>:</td>
          <td><input type="radio" name="jk" value="Laki - Laki">Laki - Laki
            <input type="radio" name="jk" value="Perempuan">Perempuan
    </td>
        </tr>
        <tr>
          <td>Agama</td>
          <td>:</td>
          <td><select name="agama" required>
          <option value="">Pilih</option>
          <option value="Islam">Islam</option>
          <option value="Kristen">Kristen</option>
          <option value="Buddha">Buddha</option>
          <option value="Hindu">Hindu</option>
      </select></td>
        </tr>
        <tr>
          <td>Profesi</td>
          <td>:</td>
          <td><input type="radio" name="profesi" value="Front End Developer">Front End Developer<br>
              <input type="radio" name="profesi" value="Back End Developer">Back End Developer<Br>
              <input type="radio" name="profesi" value="Full Stack Developer">Full Stack Developer
        </td>
        </tr>
        <tr>
          <td>Pilih Golongan</td>
          <td>:</td>
          <td>
            <select name="golongan" required>
              <option value="">Pilih</option>
              <option value="A">Golongan A</option>
              <option value="B">Golongan B</option>
              <option value="C">Golongan C</option>
            </select>
          </td>
        </tr>
        <tr>
            <td>Total Jam Kerja</td>
            <td>:</td>
            <td><input type="number" name="jam" required></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td><input type="submit" name="save" value="Penggajian"></td>
        </tr>
      </table>
    </form>
  </body>
</html>
<?php
if (isset($_POST['save'])) {
    $nama = $_POST['nama'];
    $jk = $_POST['jk'];
    $agama = $_POST['agama'];
    $profesi = $_POST['profesi'];
    $golongan = $_POST['golongan'];
    $jam = $_POST['jam'];

    class biodata
    {
        public $nama;
        public $jk;
        public $agama;
        public $profesi;

        public function __construct($nama, $jk, $agama, $profesi)
        {
            $this->nama = $nama;
            $this->jk = $jk;
            $this->agama = $agama;
            $this->profesi = $profesi;
        }
        public function data($nama, $jk, $agama, $profesi)
        {
            $data = "Nama : " . $nama . "<br>";
            $data .= "Jenis Kelamin : " . $jk . "<br>";
            $data .= "Agama : " . $agama . "<br>";
            $data .= "Profesi : " . $profesi . "<br>";
            return $data;
        }
    }
    class penggajian extends biodata
    {
        public $golongan;
        public $jam;

        public function __construct($golongan, $jam)
        {
            $this->golongan = $golongan;
            $this->jam = $jam;
        }
        public function munculdata($nama, $jk, $agama, $profesi)
        {
            return $this->data($nama, $jk, $agama, $profesi);
        }
        public function gajipokok($golongan)
        {
            if ($golongan == "A") {
                $gaji = 7500000;
            } else if ($golongan == "B") {
                $gaji = 8000000;
            } else if ($golongan == "C") {
                $gaji = 9500000;
            }
            return $gaji;
        }
        public function gajilembur($jam)
        {
            if ($jam > 173) {
                $sisajam = $jam - 173;
                $lembur = $sisajam * 45000;
            } else {
                $lembur = 0;
            }
            return $lembur;
        }
        public function data2($golongan, $jam)
        {

            $data = "Golongan : " . $golongan . "<br>";
            $data .= "Total Jam Kerja : " . $jam . " Jam" . "<br>";
            $data .= "Gaji Lembur : Rp" . $this->gajilembur($jam) . "<br>";
            $data .= "Gaji Pokok : Rp" . $this->gajipokok($golongan) . "<br>";
            return $data;

        }
        public function totalgaji($golongan, $jam)
        {
            return $this->gajilembur($jam) + $this->gajipokok($golongan);
        }
    }
    $gajian = new penggajian($nama, $jk, $agama, $profesi, $golongan, $jam);
    echo $gajian->munculdata($nama, $jk, $agama, $profesi);
    echo $gajian->data2($golongan, $jam);
    echo "Total Gaji : Rp" . $gajian->totalgaji($golongan, $jam);
}
?>
